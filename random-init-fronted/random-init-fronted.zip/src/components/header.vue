<template>
  <n-page-header subtitle="给数据库绑定随机数">
    <n-grid :cols="5">
      <n-gi>
        <n-statistic label="正片" value="125 集" />
      </n-gi>
    </n-grid>
  </n-page-header>
</template>

<script>
export default {
  name: "Header"
}
</script>