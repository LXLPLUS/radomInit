<template>
  <n-image
      width="300"
      src="./src/images/logo.png"
  />
</template>

<script>

export default {
  name: "LoginHeader",
}
</script>
