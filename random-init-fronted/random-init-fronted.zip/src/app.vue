<template>
  <n-message-provider>
    <Menu/>
  </n-message-provider>
</template>
<script setup>
import Menu from "./components/Menu.vue";
import Header from "./components/Header.vue";
</script>
