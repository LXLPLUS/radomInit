import { createRouter, createWebHashHistory } from "vue-router"
import LoginAndRegister from "../components/LoginAndRegister.vue"

const routes = [
    {
        path: "/LoginAndRegister",
        component: LoginAndRegister
    }
]

const router = createRouter({
    history:createWebHashHistory(),
    routes,
})

export default router